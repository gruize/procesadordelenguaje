package analizadorSintactico;

//Valores para el atributo sintetizado 'tipo'
//public enum tSintetiz {
	/*tBool,
	tChar,
	tNat,
	tInt,
	tFloat,
	tError,
	tInicial*/
//}
