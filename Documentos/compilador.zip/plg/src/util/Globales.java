package util;

public class Globales {
	public static boolean debug = true;
}
