package util;
// LOS ERRORES SIEMPRE TIENEN VALOR NEGATIVO
public class Errores {
	// ERRORES LEXICOS
	public static int TOKEN_NO_IDENTIFICADO = -2000;
}
