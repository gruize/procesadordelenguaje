package tablaSimbolos;

public abstract class PropsObjTS {
	
	public PropsObjTS() {
		
	}
	
	//public abstract tipoT getTipo();
	public abstract tipoT getT();
	public abstract int getTam();

}
