package tablaSimbolos;

public enum tModo {
	valor, variable
}
