package tablaSimbolos;

public enum tClase {
	variable, tipo, procedimiento, pVar,
	claseError
}
